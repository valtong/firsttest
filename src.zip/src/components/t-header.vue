<template>
  <div class="nav">
    <div class="link-list">
      <router-link to="/index/first" class="link">动态路由一</router-link>
      <router-link to="/index/second" class="link">动态路由二</router-link>
      <router-link :to="{path:'/login'}" class="link">登录</router-link>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {}
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.nav{
  position: fixed;
  top: 0;
  left: 0;
  height:100px;
  width: 100%;
  line-height:100px;
  background-color: #ccc;
}
.link-list {
  padding: 0;
  margin: 0;
  text-align: center;
}
.link {
  display: inline-block;
  margin: 0 10px;
}
</style>
