<template>
  <div class="table">
    <button @click="getData1">通过axios获取信息</button>
    <table>
      <thead>
        <tr>
          <th>姓名</th>
          <th>籍贯</th>
          <th>性别</th>
          <th>爱好</th>
        </tr>
      </thead>
      <tbody v-for="(info,index) in infos" v-bind:key="index">
        <tr>
          <td>{{info.name}}</td>
          <td>{{info.nativePlace}}</td>
          <td>{{info.sex}}</td>
          <td>{{info.hobby}}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
// import axios from 'axios'
export default {
  data () {
    return {
      infos: []
    }
  },
  methods: {
    getData1 () {
      this.$http.get('/api/testVue', {
        timeout: 1000,
        headers: {'X-Custom-Header': 'foobar'}
      }).then((res) => {
        this.infos = res.data.data.info
        console.log(res)
        console.log(this.infos)
      }).catch((err) => {
        console.log(err)
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
button{
  width: 120px;
  height:40px;
  margin:10px;
}
table{
  border: 1px solid #ccc;
  border-collapse: collapse;
  color: #000;
}
tbody{
  text-align: center;
}
th,td{
  width: 100px;
  height: 40px;
  border: 1px solid #ccc;
}
</style>
