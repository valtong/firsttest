import Vue from 'vue'
import Router from 'vue-router'
import Vuex from 'vuex'
import index from '@/page/index'
import TTable2 from '@/components/t-infotable2.vue'
import TTable1 from '@/components/t-infotable1.vue'
import TTable3 from '@/components/t-infotable3.vue'
// import login from '@/page/login'
// 注册 VueRouter 组件
Vue.use(Router)
Vue.use(Vuex)

export default new Router({
  routes: [
    // {
    //   path: '/login',
    //   component: login,
    //   meta: {
    //     requireAuth: true // 添加该字段，表示进入这个路由是需要登录的
    //   }
    // },
    {
      path: '/',
      redirect: {path: '/login'} // 写法一
      // redirect: '/index/first/t1' // 写法二
      // 错误写法：redirect: {name: 't1'}，此时内容可正确，地址不对

    },
    {
      path: '/index/:id',
      // name: 'index',
      component: index,
      redirect: {name: 't1'}, // 唯一写法，redirect之后的地址为/index/:id/t1，写成path则会使id固定，重定向错误
      children: [
        {
          path: 't1',
          name: 't1',
          component: TTable1
        },
        {
          path: 't2',
          name: 't2',
          component: TTable2
        },
        {
          path: 't3',
          name: 't3',
          component: TTable3
        }
      ]
    }
  ]
})
