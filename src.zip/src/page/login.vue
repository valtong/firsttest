<template>
    <div >
        <h1>{{ title }}</h1>
        <div>
            <span>账号</span>
            <input type="text" name="username" v-model = "username">
        </div>
        <div>
            <span>密码</span>
            <input type="password" name="password" v-model = "password">
        </div>
        <div>
            <button @click = "loginConfirm">登录</button>
        </div>
    </div>
</template>

<script>

export default {
  data () {
    return {
      title: '登录',
      username: '',
      password: ''
    }
  },
  methods: {
    setCookie (token) {
      document.cookie = token
    },
    loginConfirm () {
      console.log('username:' + this.username + 'password:' + this.password)
      var that = this
      this.$http.get('/api/testVue', {
        params: {
          userName: that.username,
          passWord: that.password
        }
      })
        .then(function (response) {
          var obj = response.data
          console.log(obj.token)
          this.setCookie(obj.token)
        })
        .catch(function (error) {
          console.log(error)
        })
    }
  },
  mounted () {

  }
}
</script>
<style scoped>
h1,
h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
