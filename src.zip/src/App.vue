<template>
  <div id="app ">
    <router-view/>
    <T-header></T-header>
    <T-index></T-index>
  </div>
</template>
@import '../src/styles/global.css';
<script>
import TIndex from '@/page/index.vue'
import THeader from '@/components/t-header.vue'
export default {
  data () {
    return {}
  },
  name: 'App',
  components: {
    TIndex,
    THeader
  }
}
</script>

<style>

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  height: 100%;
}
</style>
